import Footer from "./Footer";

export default Footer;

export { default as SeesionFooter } from "./SeesionFooter";
